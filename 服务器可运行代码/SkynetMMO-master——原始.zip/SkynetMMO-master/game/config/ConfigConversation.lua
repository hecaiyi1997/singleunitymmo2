--[[
btnName:1继续 2完成 3领取
--]]
local config = {
	[1] = {content=[[第一个对话，哈哈哈]], flag=1},
	[2] = {content=[[2有没搞错]], flag=2},
	[3] = {content=[[不服来战]], flag=1},
	[4] = {content=[[有种打我呀]], flag=1},
	[5] = {content=[[大佬别生气]], flag=1},
}

return config