local config = {
	[3000] = {
		id = 3000, name = "流浪剑客", defaultChat = {1},
	},
	[3001] = {
		id = 3001, name = "风车男孩", defaultChat = {2},
	},
	[3002] = {
		id = 3002, name = "猫女", defaultChat = {1,2,3},
	},
}
return config