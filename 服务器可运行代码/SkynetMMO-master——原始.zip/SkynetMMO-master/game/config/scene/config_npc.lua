local config = {
	[3000] = {
		id = 3000
	},
	[3001] = {
		id = 3001
	},
	[3002] = {
		id = 3002
	},
}
return config