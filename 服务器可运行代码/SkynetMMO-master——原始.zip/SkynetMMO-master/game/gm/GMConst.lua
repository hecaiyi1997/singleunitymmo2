local GMConst = {
	
}
return GMConst