local const = {
	-- monster_state = {
	-- 	patrol = 1,--巡逻
	-- 	chase = 2,--追逐
	-- 	fighting = 3,--战斗
	-- 	dead = 4,--死亡
	-- },	
	-- monster_sub_state = {
	-- 	enter = 1,
	-- 	update = 2,
	-- 	leave = 3,
	-- },
}
return const