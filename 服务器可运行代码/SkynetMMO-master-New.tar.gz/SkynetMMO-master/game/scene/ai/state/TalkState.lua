local BP = require("Blueprint")
local FightHelper = require("game.scene.FightHelper")
local SceneConst = require "game.scene.SceneConst"
local SceneHelper = require "game.scene.SceneHelper"
local Time = Time
local TalkState = BP.BaseClass(BP.FSM.FSMState)


function TalkState:OnInit(  )

	self.aoi_handle = self.blackboard:GetVariable("aoi_handle")
	self.entity = self.blackboard:GetVariable("entity")
	self.sceneMgr = self.blackboard:GetVariable("sceneMgr")
	self.aoi = self.sceneMgr.aoi
	self.entityMgr = self.sceneMgr.entityMgr
	self.monsterMgr = self.sceneMgr.monsterMgr
	self.cfg = self.blackboard:GetVariable("cfg")
	self.patrolInfo = self.entityMgr:GetComponentData(self.entity, "UMO.PatrolInfo")
	self.owner=self.blackboard:GetVariable("owner")

	self.uid = self.entityMgr:GetComponentData(self.entity, "UMO.UID")
end

function TalkState:OnEnter(  )
	self.targetEnemyEntity = self.blackboard:GetVariable("targetEnemyEntity")
	--self.dead_time = Time.time
	--self.wait_for_relive = self.cfg.ai.reborn_time/1000
end

function TalkState:OnUpdate( )
	--if self.owner==self.entity then
		--local canattack=self.entityMgr:GetComponentData(self.entity,"UMO.CanAttack")
		--if canattack then
			--self.fsm:TriggerState("FightState")
		--end
	--end
	--self:CheckAround()
	if self.owner~=self.entity then return end
	local isLive = FightHelper:IsLive(self.targetEnemyEntity)
	if isLive then
		if not self.last_retarget_time or Time.time-self.last_retarget_time > 0.5 then
			self.last_retarget_time = Time.time
			--判断是否进入攻击范围，是则发起攻击，否则追上去
			local myPos = self.entityMgr:GetComponentData(self.entity, "UMO.Position")
			local enemyPos = self.entityMgr:GetComponentData(self.targetEnemyEntity, "UMO.Position")
			local distanceFromTargetSqrt = Vector3.Distance(myPos, enemyPos)
			local isMaxOk = distanceFromTargetSqrt <= self.cfg.ai.attack_area.max_distance
			local isMinOk = distanceFromTargetSqrt >= self.cfg.ai.attack_area.min_distance
			local isOverHuntDis = distanceFromTargetSqrt > self.cfg.ai.hunt_radius
			if isOverHuntDis then
				self.targetEnemyEntity = nil
				self.blackboard:SetVariable("targetEnemyEntity", nil)
				self.entityMgr:SetComponentData(self.entity,"UMO.CanAttack",false)
				self.fsm:TriggerState("PatrolState")
			elseif isMaxOk and isMinOk then
				local canattack=self.entityMgr:GetComponentData(self.entity,"UMO.CanAttack")
				if canattack then
					self.fsm:TriggerState("FightState")
				end	
			else
				--离敌人太远或太近了，走位移动到可攻击的目标点
				local newPos = FightHelper:GetAssailableTalkPos(myPos, enemyPos, self.cfg.ai.attack_area.min_distance, self.cfg.ai.attack_area.max_distance)			
				FightHelper:ChangeTargetPos(self.entity, newPos)
			end
		end
	else
		--没有攻击目标了，回去耕田吧
		self.targetEnemyEntity = nil
		self.entityMgr:SetComponentData(self.entity,"UMO.CanAttack",false)
		self.fsm:TriggerState("PatrolState")
	end

end
--主动打人的怪需要经常判断附近有没人
function TalkState:CheckAround(  )
	if not self.cfg.ai.patrol.auto_attack_radius or self.cfg.ai.patrol.auto_attack_radius == 0 then return end
	if not self.last_check_around or Time.time - self.last_check_around > 1.5 then
		self.last_check_around = Time.time
		local nearestEnemy = self:GetNearestEnemy()
		--发现敌人了，进入战斗状态	
		if nearestEnemy == nil and self.owner==self.entity then
			self.fsm:TriggerState("PatrolState")
			self.entityMgr:SetComponentData(self.entity,"UMO.CanAttack",false)
		end
	end
end

function TalkState:GetNearestEnemy(  )
	local myPos = self.entityMgr:GetComponentData(self.entity, "UMO.Position")
	local around = self.aoi:get_around(self.aoi_handle, self.cfg.ai.patrol.auto_attack_radius, self.cfg.ai.patrol.auto_attack_radius)
	local minDistance = nil
	local nearestEnemy = nil
	for aoi_handle,_ in pairs(around) do
		local uid = self.aoi:get_user_data(aoi_handle, "uid")
		local sceneObjType = SceneHelper:GetSceneObjTypeByUID(uid)
		if sceneObjType == SceneConst.ObjectType.Role then
			-- local enemyEntity = self.aoi:get_user_data(aoi_handle, "entity")
			local enemyEntity = self.sceneMgr:GetEntity(uid)
			local enemyPos = self.entityMgr:GetComponentData(enemyEntity, "UMO.Position")
			local distanceFromTargetSqrt = Vector3.DistanceNoSqrt(myPos, enemyPos)
			if not minDistance or minDistance > distanceFromTargetSqrt then
				minDistance = distanceFromTargetSqrt
				nearestEnemy = enemyEntity
			end
		end
	end
	return nearestEnemy
end
function TalkState:OnExit(  )
end

function TalkState:OnPause(  )
end

return TalkState
