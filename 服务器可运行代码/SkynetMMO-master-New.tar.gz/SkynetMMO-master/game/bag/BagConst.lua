local BagConst = {
	--BagConst.Pos.Bag
	Pos = {
		Bag = 1,
		Warehouse = 2,
		Equip = 3,
	},
	--BagConst.MaxCell
	MaxCell = 50,
}
return BagConst