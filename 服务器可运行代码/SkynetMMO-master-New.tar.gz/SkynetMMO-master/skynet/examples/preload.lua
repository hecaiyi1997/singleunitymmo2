-- This file will execute before every lua service start
-- See config

print("PRELOAD", ...)

